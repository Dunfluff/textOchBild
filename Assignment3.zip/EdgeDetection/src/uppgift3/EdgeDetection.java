package uppgift3;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class EdgeDetection {

	private BufferedImage image;
	private double[][] magnitud;
	private double[][] vinkel;

	public BufferedImage getImage() {
		return this.image;
	}

	public EdgeDetection(BufferedImage img, int thresh) {
		int width = img.getWidth();
		int height = img.getHeight();
		double[][] Gx = new double[height][width];
		double[][] Gy = new double[height][width];

		WritableRaster inraster = img.getRaster();

		this.image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY); // Assume
																						// image
																						// is
																						// color
		int colors = 3;
		try {
			int dummy = inraster.getSample(0, 0, 2);
		} catch (Exception e) { // Try accessing blue color value!
			this.image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);// If
																						// exception,
																						// it
																						// is
																						// monochrome!
			colors = 1;
		}
		WritableRaster outraster = this.image.getRaster();

		for (int i = 0; i < width - 1; i++)
			for (int j = 0; j < height - 1; j++) {
				if (i == 0 || i == width || j == 0 || j == height) {
					outraster.setSample(i, j, 0, 0);
				} else {
					// System.out.println(width + " " + height);
					// System.out.println(i + " " + j);
					double gxr = inraster.getSample(i + 1, j - 1, 0) + 2 * inraster.getSample(i + 1, j, 0)
							+ inraster.getSample(i + 1, j + 1, 0) - inraster.getSample(i - 1, j - 1, 0)
							- 2 * inraster.getSample(i - 1, j, 0) - inraster.getSample(i - 1, j + 1, 0);
					double gxg = inraster.getSample(i + 1, j - 1, 1) + 2 * inraster.getSample(i + 1, j, 1)
							+ inraster.getSample(i + 1, j + 1, 1) - inraster.getSample(i - 1, j - 1, 1)
							- 2 * inraster.getSample(i - 1, j, 1) - inraster.getSample(i - 1, j + 1, 1);
					double gxb = inraster.getSample(i + 1, j - 1, 2) + 2 * inraster.getSample(i + 1, j, 2)
							+ inraster.getSample(i + 1, j + 1, 2) - inraster.getSample(i - 1, j - 1, 2)
							- 2 * inraster.getSample(i - 1, j, 2) - inraster.getSample(i - 1, j + 1, 2);
					double gyr = inraster.getSample(i - 1, j + 1, 0) + 2 * inraster.getSample(i, j + 1, 0)
							+ inraster.getSample(i + 1, j + 1, 0) - inraster.getSample(i - 1, j - 1, 0)
							- 2 * inraster.getSample(i, j - 1, 0) - inraster.getSample(i + 1, j - 1, 0);
					double gyg = inraster.getSample(i - 1, j + 1, 1) + 2 * inraster.getSample(i, j + 1, 1)
							+ inraster.getSample(i + 1, j + 1, 1) - inraster.getSample(i - 1, j - 1, 1)
							- 2 * inraster.getSample(i, j - 1, 1) - inraster.getSample(i + 1, j - 1, 1);
					double gyb = inraster.getSample(i - 1, j + 1, 2) + 2 * inraster.getSample(i, j + 1, 2)
							+ inraster.getSample(i + 1, j + 1, 2) - inraster.getSample(i - 1, j - 1, 2)
							- 2 * inraster.getSample(i, j - 1, 2) - inraster.getSample(i + 1, j - 1, 2);

					double A = gxr * gxr + gxg * gxg + gxb * gxb;
					double B = gyr * gyr + gyg * gyg + gyb * gyb;
					double C = gxr * gyr + gxg * gyg + gyb * gyb;

					double mag = Math.sqrt((A + B + Math.sqrt(((A - B) * (A - B)) + 4 * C * C)) / 2);

					if (mag < thresh) {
						outraster.setSample(i, j, 0, 255);
					} else {
						outraster.setSample(i, j, 0, 0);
					}
				}
			}

	}

	public static void main(String[] args) throws IOException {
		String file = "orange_flower.jpg";
		BufferedImage img = ImageIO.read(new File(file));
		EdgeDetection flip = new EdgeDetection(img, 160);
		ImageIO.write(flip.getImage(), "PNG", new File("edge" + file + ".png"));
	}
}
