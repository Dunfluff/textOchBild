package a4;

public class MainClass {
	
	public static void main(String[] args){
		TriePractice a = new TriePractice();
		SuffixTrie t = new SuffixTrie("abracadabra");
//		a.add("hejsan", "found");
//		System.out.println(a.isWord("hejsan"));
		
		System.out.println(t.longestMatch("ra"));
		
	}

}
