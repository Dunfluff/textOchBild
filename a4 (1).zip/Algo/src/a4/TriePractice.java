package a4;

import java.util.*;

public class TriePractice {
	private char c;
	private LinkedList<TriePractice> children;
	private boolean word;
	private boolean found = false;
	private Object obj;

	public TriePractice() {
		this.c = 0;
		this.children = new LinkedList();

	}

	public void add(String s, Object o) {

		if (s.isEmpty()) {
			this.obj = o;
			this.word = true;
			return;
		}

		char letter = s.charAt(0);
		for (TriePractice t : children) {

			if (t.c == letter) {
				t.add(s.substring(1), o);
				found = true;
			}
		}
		if (!found) {
			TriePractice temp = new TriePractice();
			temp.c = letter;
			this.children.add(temp);
			temp.add(s.substring(1), o);
		}
		found = false;
	}

	public Object isWord(String s) {
		if (s.isEmpty()) {
			return obj;
		}
		char letter = s.charAt(0);
		Object ret = null;
		for (TriePractice t : children) {
			if (t.c == letter) {
				ret = t.isWord(s.substring(1));

			}
		}

		return ret;
	}

	public Object suffixSearch(String input) {
		if (input.isEmpty()) {
			
			return getLeaf();
		}
		char letter = input.charAt(0);
		Object ret = null;
		for (TriePractice t : children) {
			if (t.c == letter) {
				ret = t.suffixSearch(input.substring(1));

			}
		}
		if (ret == null) {
			ret = getLeaf();

		}

		return ret;
	}

	private Object getLeaf() {
		if (!children.isEmpty()) {
			return children.getFirst().getLeaf();
		}
		return obj;
	}

}
