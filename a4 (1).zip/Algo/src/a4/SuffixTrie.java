package a4;

public class SuffixTrie {

	private TriePractice trie;

	public SuffixTrie(String txt) {
		trie = new TriePractice();

		for (int i = 0; i < txt.length(); i++) {
			trie.add(txt.substring(i), i);
		}
	}

	public int longestMatch(String input) {

		return (int) trie.suffixSearch(input);

	}

}
