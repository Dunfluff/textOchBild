
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class TextCoder {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("bible-en.txt"));
		StringBuilder sb = new StringBuilder();
		String line = br.readLine();
		int i = 0;
		while (i < 100) {
			sb.append(line);
			sb.append(System.lineSeparator());
			line = br.readLine();
			i++;
		}
		LWC lwc = new LWC();
		List code = lwc.encode(sb.toString());
		System.out.println("");
		 PrintWriter writerA = new PrintWriter("TextBefore.txt", "UTF-8");
		 writerA.println(sb.toString());
		 writerA.close();
		 int before =sb.length()*8;
		 int after = (int) (Math.log(code.size()) / Math.log(2))*code.size();
		 System.out.println("bytes needed: " + after/code.size());
		System.out.println(before);
		System.out.println(after);
		System.out.println((float)after/before*100+"%");
		PrintWriter writerB = new PrintWriter("TextAfter.txt", "UTF-8");
		lwc = new LWC();
		 writerB.println(lwc.deCode(code).toString());
		 writerB.close();
		
	}

}
