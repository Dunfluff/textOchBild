
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class LWC {
	ArrayList<String> dictionary;
	
	public LWC(){
		dictionary = new ArrayList();
		init();
	}

//	public LWC(Set<String> colourSet) {
//		dictionary = new ArrayList();
//		
//	}
//
//	private void init(Set<String> colourSet) {
//		for(String i : colourSet){
//			dictionary.add(i);
//		}
//	}

	private void init() {
		for(int i = 0; i<256; i++){
			char c = (char) i;
			dictionary.add(""+c);
		}
	}

	public List encode(String txt){
		String p = ""+txt.charAt(0);
		int i = 1;
		ArrayList result = new ArrayList();
		while(i < txt.length()){

			
			String c = "" + txt.charAt(i);
			if(dictionary.contains(""+p+c)){
				p = ""+p+c;
				if(i==txt.length()-1){
					int index = dictionary.indexOf(p);
//					System.out.print(index+ " ");
					result.add(index);
				}
			}else{
				int index = dictionary.indexOf(p);
//				System.out.print(index+ " ");
				result.add(index);
				dictionary.add(""+p+c);
				p = c;
			}
			i++;
		}
		return result;
	}
//	*    PSEUDOCODE
//	1    Initialize table with single character strings
//	2    OLD = first input code
//	3    output translation of OLD
//	4    WHILE not end of input stream
//	5        NEW = next input code
//	6        IF NEW is not in the string table
//	7               S = translation of OLD
//	8               S = S + C
//	9       ELSE
//	10              S = translation of NEW
//	11       output S
//	12       C = first character of S
//	13       OLD + C to the string table
//	14       OLD = NEW
//	15   END WHILE
	public String deCode(List code){
//		System.out.println("");
		int old = (int) code.get(0);
		StringBuilder sb = new StringBuilder();
		sb.append((dictionary.get(old)));
//		System.out.print(dictionary.get(old));
		int i = 1;
		String s = "";
		String c = "";
		while(i < code.size()){
			int newest = (int) code.get(i);
			String temp = "";
			if(dictionary.size() <= newest){
				s = dictionary.get(old);
				s = ""+s+c;
			}else{
				
				s = dictionary.get(newest);

			}
			sb.append(s);
//			System.out.print(s);
			c = s.charAt(0)+"";
			
			dictionary.add(dictionary.get(old) + c);
			old = newest;
			i++;
		}
		return sb.toString();
	}

//	public List encode(ArrayList<String> colours) {
//		String p = colours.get(0);
//		int i = 1;
//		ArrayList result = new ArrayList();
//		while(i < colours.size()){
//			String c = "" + colours.get(i);
//			if(dictionary.contains(""+p+c)){
//				p = ""+p+c;
//				if(i==colours.size()-1){
//					int index = dictionary.indexOf(p);
//					result.add(index);
//				}
//			}else{
//				System.out.println(p);
//				int index = dictionary.indexOf(p);
//				System.out.println("index = "+index);
//				result.add(index);
//				dictionary.add(""+p+c);
//				p = c;
//			}
//			i++;
//		}
//		return result;
//	}
//	
//	
}
//
//*     PSEUDOCODE
//1     Initialize table with single character strings
//2     P = first input character
//3     WHILE not end of input stream
//4          C = next input character
//5          IF P + C is in the string table
//6            P = P + C
//7          ELSE
//8            output the code for P
//9		  add P + C to the string table
//10           P = C
//11    END WHILE
//12    output code for P 
//