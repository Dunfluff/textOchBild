
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.imageio.ImageIO;

public class PicCoder2 {
	public static void main(String[] args) throws IOException {
		String file1 = "Ducky_Head_Web_Low-Res.jpg";
		BufferedImage img = ImageIO.read(new File(file1));
//		ByteArrayOutputStream baos = new ByteArrayOutputStream();
//
//		ImageIO.write(img, "jpg", baos);
//		baos.flush();
//		byte[] bytes = baos.toByteArray();
		Set<Integer> colourAm = new HashSet<Integer>();
//		StringBuilder qs = new StringBuilder();
		ArrayList<String> colours = new ArrayList();
		WritableRaster inraster  = img.getRaster();
//		adding each byte as a char, each colour is 3 bytes
//		for (int i = 0; i < bytes.length; i++) {
//			qs.append((char) bytes[i]);
//		}
//		Getting individual colours and pixels
		int pixels= 0;
		for (int i = 0; i < img.getWidth(); i++)
			for (int j = 0; j < img.getHeight(); j++) {
				pixels++;
				colourAm.add(img.getRGB(i, j));
				colours.add(img.getRGB(i, j)+"");
				
			}
		LWC lwc = new LWC();
		List code = lwc.encode(colours.toString());
		int before = colours.size()*24;
		int after = (int) (Math.log(code.size()) / Math.log(2)) * code.size();
		int colorAmounts = (int) (Math.log(colourAm.size()) / Math.log(2));
		System.out.println("Storage from start: " + pixels*24 + " bites");
		System.out.println("Bites needed to store colours: " + colorAmounts);
		System.out.println("Storage needed if low colours: " + pixels * colorAmounts + " bites");
		System.out.println("Size before Encoding: " + colours.size()*24 + " bites");
		System.out.println("Size after Encoding: " + after + " bites");
		System.out.println("bytes needed: " + after / code.size());
		System.out.println((float) after / before * 100 + "%");
	}
}
